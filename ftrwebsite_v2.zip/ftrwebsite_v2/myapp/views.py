from django.shortcuts import render,get_object_or_404, redirect
from django.http import HttpResponse, HttpResponseRedirect
from .forms import CustomUserCreationForm
from django.contrib import messages
from django.contrib.auth.models import User
from django.contrib.auth import get_user_model
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login
from .decorators import student_required, teacher_required
from .models import Vaka, Test
from django.db.models import Q
from django.contrib.auth.forms import PasswordChangeForm
from django.contrib.auth import update_session_auth_hash
from datetime import datetime



User = get_user_model()

def custom_login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        
        user = authenticate(request, username=username, password=password)
        
        if user is not None:
            # Kullanıcı doğrulandı
            if user.is_active:
                login(request, user)
                
                # Kullanıcı türüne göre yönlendirme
                if user.is_student:
                    return redirect('student_dashboard')  # Öğrenci sayfasına yönlendirme
                elif user.is_teacher:
                    return redirect('teacher_dashboard')  # Öğretmen sayfasına yönlendirme
                else:
                    return redirect('login')  # Kullanıcı türü belirtilmemişse ana sayfaya yönlendir
            else:
                messages.error(request, "Hesabınız aktif değil.")
                return redirect('login')
        else:
            messages.error(request, "Geçersiz kullanıcı adı veya şifre.")
            return redirect('login')
    
    return render(request, 'custom_login.html')  # GET isteği olduğunda login sayfasını render et

# Sadece eğitimcilerin erişebileceği sayfa
@teacher_required
def teacher_dashboard(request):
    return render(request, 'teacher_dashboard.html', {'user': request.user})
@teacher_required
def test_list(request):
    vakalar = Vaka.objects.all()
    
    if request.method == 'POST':
        for vaka in vakalar:
            aktiflik_durum = request.POST.get(f'vaka_{vaka.id}')
            vaka.aktiflik = True if aktiflik_durum == 'on' else False
            vaka.save()
        return redirect('test_list')

    return render(request, 'test_list.html', {'vakalar': vakalar})
@teacher_required
def user_list(request):
    query = request.GET.get('q', '')
    order = request.GET.get('order', 'username')
    filter_type = request.GET.get('filter', '')

    kullanicilar = User.objects.all()

    if filter_type:
        kullanicilar = kullanicilar.filter(user_type=filter_type)

    if query:
        kullanicilar = kullanicilar.filter(
            Q(username__icontains=query) |
            Q(first_name__icontains=query) |
            Q(last_name__icontains=query) |
            Q(email__icontains=query)
        )

    kullanicilar = kullanicilar.order_by(order)

    return render(request, 'user_list.html', {'kullanicilar': kullanicilar, 'order': order, 'filter_type': filter_type})
@teacher_required
def kullanici_sil(request, user_id):
    try:
        user = User.objects.get(id=user_id)
        user.delete()
    except User.DoesNotExist:
        pass
    return redirect('user_list')
@teacher_required
def register(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        password = request.POST.get('password')
        email = request.POST.get('email')
        user_type = request.POST.get('user_type')
        if User.objects.filter(username=username).exists():
            messages.error(request, 'Bu kullanıcı adı zaten mevcut.')
        else:
            User.objects.create_user(username=username, first_name=first_name, last_name=last_name, password=password, email=email, user_type=user_type)
            messages.success(request, 'Kullanıcı başarıyla eklendi.')
            return redirect('teacher_dashboard')

    return render(request, 'register.html')

##########
@teacher_required   
def test_results(request):
    return render(request, 'test_results.html')
@teacher_required
def test_results_detail(request):
    return render(request, 'test_results_detail.html')


# Sadece öğrencilerin erişebileceği sayfa
@student_required
def student_dashboard(request):
    return render(request, 'student_dashboard.html', {'user': request.user})

@student_required
def sifre_degistir(request):
    if request.method == 'POST':
        form = PasswordChangeForm(request.user, request.POST)
        if form.is_valid():
            user = form.save()
            update_session_auth_hash(request, user)  # Oturumu güncellemek için
            return redirect('student_dashboard')  # Şifre başarıyla değişti sayfasına yönlendirme
    else:
        form = PasswordChangeForm(request.user)
    return render(request, 'sifre_degistir.html', {'form': form})


@student_required
def ftr_tests(request):

    aktif_vakalar = Vaka.objects.filter(aktiflik=True)

    if request.method == 'POST':
        vaka_no = request.POST.get('vaka_no')
        vaka_t = get_object_or_404(Vaka, vaka_no=vaka_no)
        
        
        if vaka_t.aktiflik:
            new_entry = Test.objects.create(vaka_no=vaka_no, username=request.user.username, first_name=request.user.first_name, last_name=request.user.last_name)
            current_step = new_entry.current_step+1
            new_entry.current_step = current_step
            new_entry.save()

            return redirect('test', pk=new_entry.pk)
        
        else:
            return redirect(student_dashboard)
            
    
    return render(request, 'ftr_tests.html', {'aktif_vakalar': aktif_vakalar})


@student_required
def test(request,pk):
    entry = get_object_or_404(Test, pk=pk)

    if entry.username != request.user.username:
        return redirect(student_dashboard)
    else:     
        if request.method == 'POST':
            if entry.current_step == 1: 
                current_step = entry.current_step+1
                entry.current_step = current_step

                #formdan kaydedilecek veriler

                entry.save()
                context = {'entry': entry}
                return render(request, 'vaka1/step2.html', context)

            if entry.current_step == 2:
                current_step = entry.current_step+1
                entry.current_step = current_step

                #formdan kaydedilecek veriler

                entry.save()
                context = {'entry': entry}
                return render(request, 'vaka1/step3.html', context)
            
            if entry.current_step == 3:
                current_step = entry.current_step+1
                entry.current_step = current_step

                #formdan kaydedilecek veriler

                entry.save()
                context = {'entry': entry}
                return render(request, 'vaka1/step4.html', context)
            
            if entry.current_step == 4:
                current_step = entry.current_step+1
                entry.current_step = current_step

                #formdan kaydedilecek veriler

                entry.save()
                context = {'entry': entry}
                return render(request, 'vaka1/step5.html', context)
            
            if entry.current_step == 5:
                current_step = entry.current_step+1
                entry.current_step = current_step

                #formdan kaydedilecek veriler

                entry.save()
                context = {'entry': entry}
                return render(request, 'vaka1/step6.html', context)
            
            if entry.current_step == 6:
                current_step = entry.current_step+1
                entry.current_step = current_step

                #formdan kaydedilecek veriler
                entry.p1_secimler = request.POST.get('p1_secimler')

                entry.save()
                context = {'entry': entry}
                return render(request, 'vaka1/step7.html', context)
            
            if entry.current_step == 7:
                current_step = entry.current_step+1
                entry.current_step = current_step

                #formdan kaydedilecek veriler

                entry.save()
                context = {'entry': entry}
                return render(request, 'vaka1/step8.html', context)
            
            if entry.current_step == 8:
                current_step = entry.current_step+1
                entry.current_step = current_step

                #formdan kaydedilecek veriler
                entry.o1_secimler = request.POST.get('o1_secimler')

                entry.save()
                context = {'entry': entry}
                return render(request, 'vaka1/step9.html', context)
            
            if entry.current_step == 9:
                current_step = entry.current_step+1
                entry.current_step = current_step

                #formdan kaydedilecek veriler

                entry.save()
                context = {'entry': entry}
                return render(request, 'vaka1/step10.html', context)
            
            if entry.current_step == 10:
                current_step = entry.current_step+1
                entry.current_step = current_step

                #formdan kaydedilecek veriler
                # Kutuların her birinden gelen verileri alın
                box1_data = request.POST.get('box1Data')
                box2_data = request.POST.get('box2Data')
                box3_data = request.POST.get('box3Data')
                box4_data = request.POST.get('box4Data')
                box5_data = request.POST.get('box5Data')

                # JSON formatındaki verileri listeye dönüştürün
                import json
                box1_features = json.loads(box1_data) if box1_data else []
                box2_features = json.loads(box2_data) if box2_data else []
                box3_features = json.loads(box3_data) if box3_data else []
                box4_features = json.loads(box4_data) if box4_data else []
                box5_features = json.loads(box5_data) if box5_data else []

                entry.box1 = box1_features
                entry.box2 = box2_features
                entry.box3 = box3_features
                entry.box4 = box4_features
                entry.box5 = box5_features

                entry.save()
                context = {'entry': entry}
                return render(request, 'vaka1/step11.html', context)
            
            if entry.current_step == 11:
                current_step = entry.current_step+1
                entry.current_step = current_step

                #formdan kaydedilecek veriler

                entry.save()
                context = {'entry': entry}
                return redirect('tedavi', pk=entry.pk)
            
            else:
                return redirect(student_dashboard)
        context = {'entry': entry}
        return render(request, 'vaka1/step1.html', context)

@student_required
def tedavi(request,pk):
    entry = get_object_or_404(Test, pk=pk)

    if entry.username != request.user.username:
        return redirect(student_dashboard)
    else:     
        if request.method == 'POST':
            if entry.current_step == 12:
                current_step = entry.current_step+1
                entry.current_step = current_step
                entry.is_complated = True
                entry.is_complated_time = datetime.now()
                entry.save()

                return redirect(student_dashboard)
            else:
                return redirect(student_dashboard)

        context = {'entry': entry}    
    return render(request, 'vaka1/step12.html', context)

@student_required
def t11(request,pk):
    entry = get_object_or_404(Test, pk=pk)

    if entry.username != request.user.username:
        return redirect(student_dashboard)
    else:     
        if request.method == 'POST':
            if entry.current_step == 12:
                box1 = request.POST.get('box1', '[]')
                box2 = request.POST.get('box2', '[]')
                box3 = request.POST.get('box3', '[]')
                box4 = request.POST.get('box4', '[]')

                # JSON stringlerini listeye çevir
                import json
                try:
                    box1_list = json.loads(box1)
                    box2_list = json.loads(box2)
                    box3_list = json.loads(box3)
                    box4_list = json.loads(box4)
                except json.JSONDecodeError:
                    box1_list = box2_list = box3_list = box4_list = []

                # Verileri JSON string olarak saklamak için
                box1_str = ', '.join(box1_list)
                box2_str = ', '.join(box2_list)
                box3_str = ', '.join(box3_list)
                box4_str = ', '.join(box4_list)

                
                entry.t1_f1_secim=box1_str
                entry.t1_f2_secim=box2_str
                entry.t1_f3_secim=box3_str
                entry.t1_f4_secim=box4_str

                entry.save()
            
                return redirect(t12, pk=entry.pk)
            else:
                return redirect(student_dashboard)

        context = {'entry': entry}    
    return render(request, 'vaka1/t11.html', context)

@student_required
def t12(request,pk):
    entry = get_object_or_404(Test, pk=pk)

    if entry.username != request.user.username:
        return redirect(student_dashboard)
    else:     
        if request.method == 'POST':
            if entry.current_step == 12:
                entry.t1_f1_detay = request.POST.get('d1')
                entry.t1_f2_detay = request.POST.get('d2')
                entry.t1_f3_detay = request.POST.get('d3')
                entry.t1_f4_detay = request.POST.get('d4')
                entry.save()

                return redirect(tedavi, pk=entry.pk)
            else:
                return redirect(student_dashboard)

        context = {'entry': entry}    
    return render(request, 'vaka1/t12.html', context)

def test2(request):
    return render(request, 'vaka1/t12.html')
