# myapp/middleware.py

from django.contrib.sessions.models import Session
from django.utils import timezone
from django.shortcuts import redirect

def get_user_sessions(user):
    # Kullanıcının oturumlarını almak için `Session` modelini sorguluyoruz
    sessions = Session.objects.filter(expire_date__gte=timezone.now())
    user_sessions = []
    for session in sessions:
        session_data = session.get_decoded()
        if str(user.pk) == str(session_data.get('_auth_user_id')):
            user_sessions.append(session)
    return user_sessions

class SingleSessionMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        if request.user.is_authenticated:
            # Kullanıcının oturumlarını alın
            user_sessions = get_user_sessions(request.user)
            
            if len(user_sessions) > 1:  # Eğer kullanıcıya ait birden fazla oturum varsa
                for session in user_sessions[:-1]:  # Son oturum hariç diğer oturumları sil
                    session.delete()
                return redirect('login')  # Kullanıcıyı tekrar giriş yapması için login sayfasına yönlendir

        response = self.get_response(request)
        return response
