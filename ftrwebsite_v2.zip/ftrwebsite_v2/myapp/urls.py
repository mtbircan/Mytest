from django.contrib import admin
from django.urls import path, include
from myapp import views
from django.contrib.auth.views import LogoutView
from django.conf import settings
from django.conf.urls.static import static
from django.contrib.auth import views as auth_views

import random
import string
def generate_random_string():
    # Harfler ve rakamlar kümesini tanımlayın
    characters = string.ascii_letters + string.digits  # ascii_letters: a-zA-Z, digits: 0-9
    
    # Rastgele bir uzunluk seçin (4 ila 8 arasında)
    length = random.randint(4, 12)
    
    # Rastgele karakterler ve sayılar içeren bir dizge oluşturun
    random_string = ''.join(random.choices(characters, k=length))
    random_string2 = ''.join(random.choices(characters, k=length))
    test_r = 'test/' + random_string + '<int:pk>' + random_string2
    return test_r

def generate_random_string2():
    # Harfler ve rakamlar kümesini tanımlayın
    characters = string.ascii_letters + string.digits  # ascii_letters: a-zA-Z, digits: 0-9
    
    # Rastgele bir uzunluk seçin (4 ila 8 arasında)
    length = random.randint(4, 12)
    
    # Rastgele karakterler ve sayılar içeren bir dizge oluşturun
    random_string = ''.join(random.choices(characters, k=length))
    random_string2 = ''.join(random.choices(characters, k=length))
    tedavi_r = 'tedavi/' + random_string + '<int:pk>' + random_string2
    return tedavi_r

urlpatterns = [
    path('', views.custom_login, name='login'),
    path('login/', views.custom_login, name='login'),
    path('teacher_dashboard/', views.teacher_dashboard, name='teacher_dashboard'),
    path('test_list/', views.test_list, name='test_list'),
    path('test_results/', views.test_results, name='test_results'),
    path('test_results_detail/', views.test_results_detail, name='test_results_detail'),
    path('user_list/', views.user_list, name='user_list'),
    path('kullanici-sil/<int:user_id>/', views.kullanici_sil, name='user_delete_url'),
    path('sifre-degistir/', views.sifre_degistir, name='sifre_degistir'),
    path('register/', views.register, name='register'),
    path('student_dashboard/', views.student_dashboard, name='student_dashboard'),
    path('ftr_tests/', views.ftr_tests, name='ftr_tests'),
    path(generate_random_string(), views.test, name='test'),
    path(generate_random_string2(), views.tedavi, name='tedavi'),
    path('tedavi/t11<int:pk>', views.t11, name='t11'),
    path('tedavi/t12<int:pk>', views.t12, name='t12'),
    path('logout/', LogoutView.as_view(), name='logout'),
    path('test2/', views.test2, name='test2'),
]+ static(settings.STATIC_URL, document_root=settings.STATIC_ROOT) + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)