from django.db import models
from django.contrib.auth.models import AbstractUser

# Create your models here.
class User(AbstractUser):
    STUDENT = 'student'
    TEACHER = 'teacher'
    
    USER_TYPE_CHOICES = [
        (STUDENT, 'Student'),
        (TEACHER, 'Teacher'),
    ]
    
    user_type = models.CharField(max_length=10, choices=USER_TYPE_CHOICES)
    
    def is_student(self):
        return self.user_type == self.STUDENT
    
    def is_teacher(self):
        return self.user_type == self.TEACHER

class Vaka(models.Model):
    vaka_no = models.CharField(max_length=10)
    aktiflik = models.BooleanField(default=True)

    def __str__(self):
        return self.vaka_no
    
class Test(models.Model):
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    vaka_no = models.IntegerField(default=1)
    current_step = models.IntegerField(default=0)
    is_complated = models.BooleanField(default=False)
    is_complated_time = models.DateTimeField(null=True, blank=True)
    username = models.TextField()
    first_name = models.TextField()
    last_name = models.TextField()

    p1_secimler = models.TextField()
    o1_secimler = models.TextField()

    box1 = models.TextField()
    box2 = models.TextField()
    box3 = models.TextField()
    box4 = models.TextField()
    box5 = models.TextField()

    t1_f1_secim = models.TextField()
    t1_f1_detay = models.TextField()
    t1_f2_secim = models.TextField()
    t1_f2_detay = models.TextField()
    t1_f3_secim = models.TextField()
    t1_f3_detay = models.TextField()
    t1_f4_secim = models.TextField()
    t1_f4_detay = models.TextField()

    t2_f1_secim = models.TextField()
    t2_f1_detay = models.TextField()
    t2_f2_secim = models.TextField()
    t2_f2_detay = models.TextField()
    t2_f3_secim = models.TextField()
    t2_f3_detay = models.TextField()
    t2_f4_secim = models.TextField()
    t2_f4_detay = models.TextField()

    t3_f1_secim = models.TextField()
    t3_f1_detay = models.TextField()
    t3_f2_secim = models.TextField()
    t3_f2_detay = models.TextField()
    t3_f3_secim = models.TextField()
    t3_f3_detay = models.TextField()
    t3_f4_secim = models.TextField()
    t3_f4_detay = models.TextField()

    t4_f1_secim = models.TextField()
    t4_f1_detay = models.TextField()
    t4_f2_secim = models.TextField()
    t4_f2_detay = models.TextField()
    t4_f3_secim = models.TextField()
    t4_f3_detay = models.TextField()
    t4_f4_secim = models.TextField()
    t4_f4_detay = models.TextField()

    t5_f1_secim = models.TextField()
    t5_f1_detay = models.TextField()
    t5_f2_secim = models.TextField()
    t5_f2_detay = models.TextField()
    t5_f3_secim = models.TextField()
    t5_f3_detay = models.TextField()
    t5_f4_secim = models.TextField()
    t5_f4_detay = models.TextField()

    t6_f1_secim = models.TextField()
    t6_f1_detay = models.TextField()
    t6_f2_secim = models.TextField()
    t6_f2_detay = models.TextField()
    t6_f3_secim = models.TextField()
    t6_f3_detay = models.TextField()
    t6_f4_secim = models.TextField()
    t6_f4_detay = models.TextField()

    t7_f1_secim = models.TextField()
    t7_f1_detay = models.TextField()
    t7_f2_secim = models.TextField()
    t7_f2_detay = models.TextField()
    t7_f3_secim = models.TextField()
    t7_f3_detay = models.TextField()
    t7_f4_secim = models.TextField()
    t7_f4_detay = models.TextField()

    t8_f1_secim = models.TextField()
    t8_f1_detay = models.TextField()
    t8_f2_secim = models.TextField()
    t8_f2_detay = models.TextField()
    t8_f3_secim = models.TextField()
    t8_f3_detay = models.TextField()
    t8_f4_secim = models.TextField()
    t8_f4_detay = models.TextField()

    t9_f1_secim = models.TextField()
    t9_f1_detay = models.TextField()
    t9_f2_secim = models.TextField()
    t9_f2_detay = models.TextField()
    t9_f3_secim = models.TextField()
    t9_f3_detay = models.TextField()
    t9_f4_secim = models.TextField()
    t9_f4_detay = models.TextField()

    t10_f1_secim = models.TextField()
    t10_f1_detay = models.TextField()
    t10_f2_secim = models.TextField()
    t10_f2_detay = models.TextField()
    t10_f3_secim = models.TextField()
    t10_f3_detay = models.TextField()
    t10_f4_secim = models.TextField()
    t10_f4_detay = models.TextField()

    t11_f1_secim = models.TextField()
    t11_f1_detay = models.TextField()
    t11_f2_secim = models.TextField()
    t11_f2_detay = models.TextField()
    t11_f3_secim = models.TextField()
    t11_f3_detay = models.TextField()
    t11_f4_secim = models.TextField()
    t11_f4_detay = models.TextField()

    duration1 = models.DurationField(null=True, blank=True)
    duration2 = models.DurationField(null=True, blank=True)
    duration3 = models.DurationField(null=True, blank=True)
    duration4 = models.DurationField(null=True, blank=True)
    duration5 = models.DurationField(null=True, blank=True)
    duration6 = models.DurationField(null=True, blank=True)

    not1 = models.TextField()
    not2 = models.TextField()
    not3 = models.TextField()

    is_1 = models.BooleanField(default=False)
    is_2 = models.BooleanField(default=False)
    is_3 = models.BooleanField(default=False)

    time1 = models.DateTimeField(null=True, blank=True)
    time2 = models.DateTimeField(null=True, blank=True)
    time3 = models.DateTimeField(null=True, blank=True)

    y_duration1 = models.DurationField(null=True, blank=True)
    y_duration2 = models.DurationField(null=True, blank=True)
    y_duration3 = models.DurationField(null=True, blank=True)

    def __str__(self):
        return self.vaka_no