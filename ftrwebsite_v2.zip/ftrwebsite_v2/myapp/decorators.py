# myapp/decorators.py

from django.shortcuts import redirect
from functools import wraps

def student_required(view_func):
    @wraps(view_func)
    def _wrapped_view(request, *args, **kwargs):
        if not request.user.is_authenticated:
            return redirect('login')
        if not request.user.is_student:
            return redirect('/')  # Eğer kullanıcı öğrenci değilse ana sayfaya yönlendir
        return view_func(request, *args, **kwargs)
    return _wrapped_view

def teacher_required(view_func):
    @wraps(view_func)
    def _wrapped_view(request, *args, **kwargs):
        if not request.user.is_authenticated:
            return redirect('login')
        if not request.user.is_teacher:
            return redirect('/')  # Eğer kullanıcı öğrenci değilse ana sayfaya yönlendir
        return view_func(request, *args, **kwargs)
    return _wrapped_view